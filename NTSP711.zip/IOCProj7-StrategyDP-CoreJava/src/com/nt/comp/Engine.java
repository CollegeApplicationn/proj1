package com.nt.comp;

public interface Engine {
	public void start();
	public void stop();

}
