package com.nt.dao;

import com.nt.entity.UserHLO;

public interface LoginDAO {
	public long  authenticate(UserHLO bo);

}
