package com.nt.command;

import lombok.Data;

@Data
public class UserCommand {
	private  String user;
	private String pwd;
}
