package com.nt.beans;

public class B {
	private  A  a;
	
	public   B (A  a) {
		this.a=a;
	}
	
	@Override
	public String toString() {
		return "B [a=" + a + "]";
	}
	

}
