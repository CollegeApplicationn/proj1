package com.nt.beans;

public class DecthlonStrore {
	private   KalanjeeShoe  shoe;

	public DecthlonStrore(KalanjeeShoe shoe) {
		this.shoe = shoe;
	}

	@Override
	public String toString() {
		return "DecthlonStrore [shoe=" + shoe + "]";
	}
	
	

}
