package com.nt.external;

public interface ExternalIPLScoreComp {
	 
	public    String    getScore(int mid);

}
