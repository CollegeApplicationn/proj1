package com.nt.beans;

public class B {
	private  A  a;
	
	public void setA(A  a) {
		this.a=a;
	}
	
	@Override
	public String toString() {
		return "B ....";
	}
	

}
