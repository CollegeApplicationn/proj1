package com.nt.beans;

public class CricketBat {
	
	public   void  scoreRuns() {
		System.out.println(Math.round(Math.random()*100) +" runs are scored");
	}

}
