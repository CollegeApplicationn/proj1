function validate()
{ 
   if( document.Registration.name.value == "" )
   {
    
     document.Registration.name.focus() ;
     return false;
   }
   




  if( document.Registration.phone.value == "" ||
           isNaN( document.Registration.phone.value) ||
           document.Registration.phone.value.length != 10 )
   {
     
     document.Registration.phone.focus() ;
     return false;
   }
   



   
   if ( ( Registration.gender[0].checked == false ) && ( Registration.gender[1].checked == false ) )
   {
  
   return false;
   }   




   
   if( document.Registration.course.value == "-1" )
   {
    
    
     return false;
   }   
   
   


 var emaill = document.Registration.email.value;
 var atpos = emaill.indexOf("@");
 var  dotpos = emaill.lastIndexOf(".");
 if (emaill == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
 {
    
     document.Registration.email.focus() ;
     return false
 }




if( document.Registration.addrs.value == "" )
   {
     
     document.Registration.addrs.focus() ;
     return false;
   }


 
   return( true );
}