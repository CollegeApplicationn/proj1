package com.nt.service;

import org.apache.log4j.Logger;

import com.nt.bo.LoginBO;
import com.nt.controller.ApplicantControllerServlet;
import com.nt.dao.LoginDAO;
import com.nt.dao.LoginDAOImpl;
import com.nt.dto.LoginDTO;

public class LoginServiceImpl implements LoginService {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
private LoginDAO dao;
	
	//Constructor
		public LoginServiceImpl() {
			dao=new LoginDAOImpl();
		
		}//constructor()
	
	@Override
	public String generateResult(LoginDTO dto) {
		LoginBO bo=null;
		int count=0;
		
		//create BO class Object
		bo=new LoginBO();
		bo.setName(dto.getName());
		bo.setTypeOfCandidate(dto.getTypeOfCandidate());
		bo.setUserID(dto.getUserID());
		bo.setPwd(dto.getPwd());
		
	   //use dao
		count=dao.insert(bo);
		
		if(count==0)
			return "Registration Failed! Try Agin...";
		else
			return "Registration Sucessfull! ";
	}
   public boolean validateService(String u,String p) {
	   LoginDAOImpl dao1=new LoginDAOImpl();
	   boolean status=false;
	   try {
		status=dao1.validate(u,p);
	} catch (Exception e) {
		
		log.error(e);

	}
	   return status;
   }
	
}//class