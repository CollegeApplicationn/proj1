package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import com.nt.bo.ApplicantBO;
import com.nt.bo.FacultyBO;
import com.nt.bo.StudentBO;
import com.nt.dao.AdminDAO;
import com.nt.dao.AdminDAOImpl;
import com.nt.dto.ApplicantDTO;
import com.nt.dto.FacultyDTO;
import com.nt.dto.StudentDTO;

public class AdminServiceImpl implements AdminService {
     private AdminDAO dao;
     
     public AdminServiceImpl() {
		dao=new AdminDAOImpl();
	}
	@Override
	public List<ApplicantDTO> viewApplicantDetails() {
		List<ApplicantBO>listBO=null;
		List<ApplicantDTO>listDTO=null;
		ApplicantDTO dto=null;
		//use dao
		listBO=dao.getApplicantDetails();
		//convert listBO to listDTO
		listDTO=new ArrayList();
		for(ApplicantBO bo:listBO) {
			//copy Each BO class obj to each DTO class object
			dto=new ApplicantDTO();
			dto.setAppNo(bo.getAppNo());
			dto.setName(bo.getName());
			dto.setDate(bo.getDate());
			dto.setPhno(bo.getPhno());
			dto.setGender(bo.getGender());
			dto.setCourse(bo.getCourse());
			dto.setEmailID(bo.getEmailID());
			dto.setAddr(bo.getAddr());
			dto.setSrNo(listDTO.size()+1);
			//add dto to ListDTO
			listDTO.add(dto);
		}//for
		return listDTO;
	}//method
	
	@Override
	public List<StudentDTO> viewStudentDetails()  {
		List<StudentBO>listBO=null;
		List<StudentDTO>listDTO=null;
		StudentDTO dto=null;
		//use dao
		listBO=dao.getStudentDetails();
		//convert listBO to listDTO
		listDTO=new ArrayList();
		for(StudentBO bo:listBO) {
			//copy Each BO class obj to each DTO class object
			dto=new StudentDTO();
			dto.setSno(bo.getSno());
			dto.setName(bo.getName());
			dto.setAge(bo.getAge());
			dto.setAddrs(bo.getAddrs());
			dto.setEmail(bo.getEmail());
			dto.setPhno(bo.getPhno());
			dto.setSrNo(listDTO.size()+1);
			//add dto to ListDTO
			listDTO.add(dto);
			
		}//for
		return listDTO;
	}//method
	
	
	public List<FacultyDTO> viewfacultyDetails(){
		List<FacultyBO>listBO=null;
		List<FacultyDTO>listDTO=null;
		FacultyDTO dto=null;
		//use DAO
		listBO=dao.getFacultyDetails();
		//convert listBO to listDTO
				listDTO=new ArrayList();
				for(FacultyBO bo:listBO) {
					//copy Each BO class obj to each DTO class object
					dto=new FacultyDTO();
					dto.setSno(bo.getSno());
					dto.setName(bo.getName());
					dto.setEmail(bo.getEmail());
					dto.setPhno(bo.getPhno());
					dto.setSrNo(listDTO.size()+1);
					//add dto to ListDTO
					listDTO.add(dto);
					
				}//for
				return listDTO;
		
		
	}//Faculty
    
	public  String rejectApplicationService(int id){
		AdminDAOImpl dao1=new AdminDAOImpl();
		int count=dao1.RejectApplicantDetails(id);
		
		if(count==0)
			return "Applicant not found for Deletion";
		else
			return "Applicant found and deleted";
		
	}//reject()
	
	public  String approveApplicationService(int id){
		AdminDAOImpl dao1=new AdminDAOImpl();
		int count=dao1.ApproveApplicantDetails(id);
		
		if(count==0)
			return "Applicant not found for Approve";
		else
			return "Applicant found and Approved";
		
	}//reject()
	
	 
}//class
