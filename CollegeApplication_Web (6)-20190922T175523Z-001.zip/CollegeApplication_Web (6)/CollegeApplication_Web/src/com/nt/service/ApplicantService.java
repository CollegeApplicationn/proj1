package com.nt.service;

import com.nt.dto.ApplicantDTO;

public interface ApplicantService {
    public String generateResult(ApplicantDTO dto);
}
