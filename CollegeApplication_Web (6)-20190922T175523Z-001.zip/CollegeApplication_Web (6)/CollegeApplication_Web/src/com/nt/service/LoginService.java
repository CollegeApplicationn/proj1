package com.nt.service;

import com.nt.dto.LoginDTO;

public interface LoginService {
	  public String generateResult(LoginDTO dto);
}
