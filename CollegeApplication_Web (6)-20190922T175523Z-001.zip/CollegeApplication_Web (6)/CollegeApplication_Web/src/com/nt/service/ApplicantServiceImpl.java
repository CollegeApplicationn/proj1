package com.nt.service;

import com.nt.bo.ApplicantBO;
import com.nt.dao.ApplicantDAO;
import com.nt.dao.ApplicantDAOImpl;
import com.nt.dto.ApplicantDTO;

public class ApplicantServiceImpl implements ApplicantService {
	private ApplicantDAO dao;
	
	//Constructor
		public ApplicantServiceImpl() {
			dao=new ApplicantDAOImpl();
		
		}//constructor()

	@Override
	public String generateResult(ApplicantDTO dto) {
		ApplicantBO bo=null;
		int count=0;
		
		//create BO class Object
		bo=new ApplicantBO();
		
		bo.setName(dto.getName());
		bo.setDate(dto.getDate());
		bo.setPhno(dto.getPhno());
		bo.setGender(dto.getGender());
		bo.setCourse(dto.getCourse());
		bo.setEmailID(dto.getEmailID());
		bo.setAddr(dto.getAddr());
		
	   //use dao
		count=dao.insert(bo);
		
		if(count==0)
			return "Registration Failed! Try Agin...";
		else
			return "Registration Sucessfull! Your Application Number is " +count;
		
		
	}//method

}//class
