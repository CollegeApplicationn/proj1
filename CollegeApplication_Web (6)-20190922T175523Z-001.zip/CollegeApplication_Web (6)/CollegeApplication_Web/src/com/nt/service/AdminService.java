package com.nt.service;

import java.util.List;

import com.nt.dto.ApplicantDTO;
import com.nt.dto.FacultyDTO;
import com.nt.dto.StudentDTO;

public interface AdminService {
    public List<ApplicantDTO> viewApplicantDetails();
    public List<StudentDTO> viewStudentDetails();
    public List<FacultyDTO> viewfacultyDetails();
}
