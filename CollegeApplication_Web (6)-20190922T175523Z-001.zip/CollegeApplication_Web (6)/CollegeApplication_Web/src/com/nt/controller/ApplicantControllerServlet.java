package com.nt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


import com.nt.dto.ApplicantDTO;
import com.nt.service.ApplicantService;
import com.nt.service.ApplicantServiceImpl;



@WebServlet("/controller.jsp")
public class ApplicantControllerServlet extends HttpServlet {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
	  
	  
	  @Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		  ApplicantService service=null;
		 PrintWriter pw=null;
		 String name=null;
		 String date=null;
		 String gender=null;
		 String course=null;
		 String emailID=null;
		 String result=null;
		 String addr=null;
	     long phno=0;
	     
	     ApplicantDTO dto=null;
	     service=new ApplicantServiceImpl();
	   
	    
	     //generalSettings
	     pw=res.getWriter();
	     res.setContentType("text/html");
	    	 
	    	 
	     try {
	    	 
	    	 
     //read form data
	     name=req.getParameter("name");
	     date=req.getParameter("dob");
	     phno=Long.parseLong(req.getParameter("phone"));
	     gender=req.getParameter("gender");
	     course=req.getParameter("course");
	     emailID=req.getParameter("email");
	     addr=req.getParameter("addrs");
	     
	    
	
			
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			
			Date date1=sdf.parse(date);
		    
	     //create DTO class object
	     dto=new ApplicantDTO();
	    
	     dto.setName(name);
	     dto.setDate(date1);
	     dto.setPhno(phno);
	     dto.setGender(gender);
	     dto.setCourse(course);
	     dto.setEmailID(emailID);
	     dto.setAddr(addr);
	     //create and use service class object
	     result=service.generateResult(dto);
	     pw.println("<h2 style='color:green;text-align:center'>"+result+"</h2>");
         } 
        catch (Exception e) {
        	log.error(e);
			} 
		//add hyperlink
		pw.println("<br><a href='Virtusa.html'>Home</a>");
		//close stream
		pw.close();
	}//doGet(-)
	  
	  @Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		  try {
	    		doGet(req, res);
	    		}
	    		catch(Exception e) {
	    			log.fatal(e);
	    		}
	}
  
}//class
