package com.nt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nt.service.LoginServiceImpl;

@WebServlet("/adminlogin")
public class AdminLoginController extends HttpServlet {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
    
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
   	    PrintWriter pw=null;
   	    String u=null;
   	 String p=null;
   	 RequestDispatcher rd=null;
   	LoginServiceImpl service=new LoginServiceImpl();
             try {
    	  //GENERAL SETTINGS
    	   pw=res.getWriter();
    	   res.setContentType("text/html");
    	   //read form data
    	  u=req.getParameter("user");
    	  p=req.getParameter("psw");
    	  
    	 
    		  if(service.validateService(u,p)){ 
			        rd=req.getRequestDispatcher("admin.html");  
			        rd.forward(req,res);  
			    }  
			    else{  
			        pw.print("Sorry username or password error");  
			        rd=req.getRequestDispatcher("index.html");  
			        rd.include(req,res);  
			    }
		} catch (Exception e) {
			
			log.error(e);

		}  
    	          
    	      
    	     
    	   
    	
    	
    }//method
    
    @Override
    	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    		try {
    		doGet(req, res);
    		}
    		catch(Exception e) {
    			log.error(e);

    		}
    	}//doPost()
	
	
}//class
