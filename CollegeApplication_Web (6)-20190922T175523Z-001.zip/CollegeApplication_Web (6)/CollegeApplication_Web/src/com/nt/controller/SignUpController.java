package com.nt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nt.dto.LoginDTO;
import com.nt.service.LoginService;
import com.nt.service.LoginServiceImpl;

@WebServlet("/signupcontroller")
public class SignUpController extends HttpServlet {
	
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String name=null;
		String toc=null;
		String userid=null;
		String result=null;
		String pass=null;
		LoginService service=null;
		LoginDTO dto=null;
		service=new LoginServiceImpl();
		try {
		//generalSettings
	     pw=res.getWriter();
	     res.setContentType("text/html");
	     //Read form data
	     name=req.getParameter("name");
	     toc=req.getParameter("toc");
	     userid=req.getParameter("user");
	     pass=req.getParameter("psw");
	     
	     //create DTO class object
	     dto=new LoginDTO();
	     dto.setName(name);
	     dto.setTypeOfCandidate(toc);
	     dto.setUserID(userid);
	     dto.setPwd(pass);
	     
	   //create and use service class object
	     
			result=service.generateResult(dto);
			pw.println("<h1 style='color:green;text-align:center'>"+result+"</h1>");
			
		} catch (Exception e) {
			
			log.error(e);

		} 
	         pw.println("<br><center><a href='Login.html'>Login Here</a></center>");
	       //add hyperlink
			pw.println("<br><a href='Virtusa.html'>Home</a>");
			//close stream
			pw.close();
	     
		
		
	}//doGet()
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		try {
    		doGet(req, res);
    		}
    		catch(Exception e) {
    			log.error(e);

    		}
	}//doPost()

}//class
