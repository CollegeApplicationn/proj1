package com.nt.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nt.dto.ApplicantDTO;
import com.nt.service.AdminService;
import com.nt.service.AdminServiceImpl;

@WebServlet("/admin_controller")
public class AdminController extends HttpServlet {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	List<ApplicantDTO>listDTO=null;
    	 RequestDispatcher rd=null;
    	 AdminService service=null;
    	
    	service=new AdminServiceImpl();
    	try {
    	//use service
    	listDTO=service.viewApplicantDetails();
    	//keep results in request scope
    	
	    req.setAttribute("report",listDTO);
	   
    	 //forward to View comp
	    rd=req.getRequestDispatcher("check_applicant_details.jsp");
	    rd.forward(req,res);
    	 }
	    catch(Exception e) {
	    	log.error(e);
	    	try {
	    	rd=req.getRequestDispatcher("/error.html");
	    	rd.forward(req,res);
	    	}
	    	catch(Exception e1) {
	    		log.error(e1);

	    	}
	    	
	    }
    }//doGet()
    
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	try {
    	doGet(req, res);
    	}
    	catch(Exception e) {
    		log.error(e);

    	}
    }
    
    
	
}//class
