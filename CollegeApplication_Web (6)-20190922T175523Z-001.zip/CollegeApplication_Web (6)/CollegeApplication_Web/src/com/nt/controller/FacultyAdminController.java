package com.nt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nt.dto.FacultyDTO;
import com.nt.service.AdminService;
import com.nt.service.AdminServiceImpl;

@WebServlet("/faculty_Controller")
public class FacultyAdminController extends HttpServlet {
	
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	List<FacultyDTO>listDTO=null;
    	 RequestDispatcher rd=null;
    	 AdminService service=new AdminServiceImpl();
    	try {
    	//use service
    	listDTO=service.viewfacultyDetails();
    	//keep results in request scope
	    req.setAttribute("report1",listDTO);
	    //forward to View comp
	    rd=req.getRequestDispatcher("check_Faculty_details.jsp");
	    rd.forward(req,res);
	    }
	    catch(Exception e) {
	    	log.error(e);

	    	try {
	    	rd=req.getRequestDispatcher("/error.html");
	    	rd.forward(req,res);
	    	}
	    	 catch(Exception e1) {
	    		 log.error(e);

	    	 }
	    }
    	
    }//doGet()
    
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	
    	try {
    		doGet(req, res);
    		}
    		catch(Exception e) {
    			log.error(e);

    		}
    }
  


}//servlet
