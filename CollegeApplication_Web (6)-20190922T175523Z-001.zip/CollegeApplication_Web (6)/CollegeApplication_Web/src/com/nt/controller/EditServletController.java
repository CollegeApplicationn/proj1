package com.nt.controller;

import java.io.IOException;

import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nt.service.AdminServiceImpl;
@WebServlet("/EditServlet")
public class EditServletController extends HttpServlet {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		int id=Integer.parseInt(req.getParameter("id"));
		AdminServiceImpl service=new AdminServiceImpl(); 
	         Map map=null;
	        
	        try {
	        	
				service.approveApplicationService(id);
				
			} catch (Exception e) {
				
				log.error(e);

			}  
	        res.sendRedirect("admin_controller");  
	}
}
