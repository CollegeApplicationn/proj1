package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;

import com.nt.bo.LoginBO;
import com.nt.controller.ApplicantControllerServlet;

public class LoginDAOImpl implements LoginDAO {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
	 private static final String LOG_DET_INSERT="INSERT INTO LOGIN VALUES(?,?,?,?,?)";
	 private static final String GET_ID="select LOGIN_SEQ.NEXTVAL from dual";
	 private static final String LOGIN_QUERY="SELECT * FROM LOGIN WHERE USER_ID=? AND PASSWORD=?";
	
	 private static Connection getPooledConnection(){
	   	 Connection con=null;
	   	 InitialContext ic=null;
	   	 DataSource ds=null;
	   	 try {
	   	 //create initalContext obj
	   	 ic=new InitialContext();
	   	 ds=(DataSource) ic.lookup("java:/comp/env/mypool");
	   	 con=ds.getConnection();
	   	 }
	   	 catch(Exception e) {
	   		 log.error(e);
	   	 }
			return con;
	   	 
	    }
	@Override
	public int insert(LoginBO bo) {
		Connection con=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		int count=0;
		 int app_Id=0;
		 ResultSet rs=null;
		 try {
		//get Connection
			 con=getPooledConnection();
		ps1=con.prepareStatement(GET_ID);
		  rs = ps1.executeQuery();
		   if(rs.next())
		      app_Id=rs.getInt(1);
		
			
		//create Prepare Statement
		ps2=con.prepareStatement(LOG_DET_INSERT);
		//set values to query params
		ps2.setInt(1,app_Id);
		ps2.setString(2,bo.getName());
		ps2.setString(3,bo.getTypeOfCandidate());
		ps2.setString(4, bo.getUserID());
		ps2.setString(5,bo.getPwd());
		
		//execute the Query
		count=ps2.executeUpdate();
	    
		
		}catch (Exception e) {
			log.error(e);

		}
		finally {
			//close jdbc obj
			try {
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(ps2!=null)
					ps2.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(ps1!=null)
					ps1.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				 if(con!=null) {
					 con.close();
				 }
			}
			catch(SQLException se) {
				log.error(se);

			}
		}
		return app_Id;
	
	}//method
	
	public  boolean validate(String user,String pass){  
		boolean status=false;  
		Connection con=null;  
		PreparedStatement ps=null;
		ResultSet rs=null;
		 try {
				
			//get Connection
			 con=getPooledConnection();
		ps=con.prepareStatement(LOGIN_QUERY);  
		ps.setString(1,user);  
		ps.setString(2,pass);  
		      
		rs=ps.executeQuery();  
		status=rs.next();  
		
		
	}catch (Exception e) {
		log.error(e);

	}
	finally {
		//close jdbc obj
		try {
			if(rs!=null)
				rs.close();
		}
		catch(SQLException se) {
			log.error(se);

		}
		try {
			if(ps!=null)
				ps.close();
		}
		catch(SQLException se) {
			log.error(se);

		}
		try {
			if(con!=null)
				con.close();
		}
		catch(SQLException se) {
			log.error(se);

		}
	}
	return status;  
		}//method  
	
	
     
}//class
