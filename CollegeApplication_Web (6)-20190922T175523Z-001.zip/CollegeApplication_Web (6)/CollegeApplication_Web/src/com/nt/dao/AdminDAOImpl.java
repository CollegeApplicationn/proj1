package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;

import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;

import com.nt.bo.ApplicantBO;
import com.nt.bo.FacultyBO;
import com.nt.bo.StudentBO;
import com.nt.controller.ApplicantControllerServlet;

public class AdminDAOImpl implements AdminDAO {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
	private static final String GET_APP_DETAILS="SELECT * FROM APPLICANT";
	private static final String GET_STUD_DETAILS="SELECT * FROM STUDENTT";
	private static final String REJECT_APP="DELETE APPLICANT WHERE APP_NO=?";
	private static final String APPROVE_APP="UPDATE APPLICANT SET APPSTATUS='CONGO! APPROVED' WHERE APP_NO=?";
	 private static final String GET_FAC_DETAILS="SELECT * FROM FACULTY";
	private static Connection getPooledConnection(){
	   	 Connection con=null;
	   	 InitialContext ic=null;
	   	 DataSource ds=null;
	   	 try {
	   	 //create initalContext obj
	   	 ic=new InitialContext();
	   	 ds=(DataSource) ic.lookup("java:/comp/env/mypool");
	   	 con=ds.getConnection();
	   	 }
	   	 catch(Exception e) {
	   		 log.error(e);
	   	 }
			return con;
	   	 
	    }
  
	@Override
	public List<ApplicantBO> getApplicantDetails()  {
		Connection con=null;
		PreparedStatement ps=null;
	    ResultSet rs=null;
	    List<ApplicantBO> listBO=null;	
		ApplicantBO bo=null;
		
		
		try {
			//get connection
		
		 con=getPooledConnection();
		ps=con.prepareStatement(GET_APP_DETAILS);
		rs=ps.executeQuery();
		//copy ResultSet obj records  to ListBO 
		listBO=new ArrayList();
        
		while(rs.next()) {
			//copy each record to one BO class object
			bo=new ApplicantBO();
			bo.setAppNo(rs.getInt(1));
			bo.setName(rs.getString(2));
			bo.setDate(rs.getDate(3));
			bo.setPhno(rs.getLong(4));
			bo.setGender(rs.getString(5));
			bo.setCourse(rs.getString(6));
			bo.setEmailID(rs.getString(7));
			bo.setAddr(rs.getString(8));
			//add Bo class objs to ListBO
			listBO.add(bo);
		}//while
		
		}catch (Exception e) {
			log.error(e);

		}
		finally {
			//close jdbc obj
			try {
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
		}
		return listBO;
		
		
	}//getApplicantDetails()
	
	@Override
	public List<StudentBO> getStudentDetails() {
		Connection con=null;
		PreparedStatement ps=null;
	    ResultSet rs=null;
	    List<StudentBO> listBO=null;	
		StudentBO bo=null;
		 try {
		//get pooled connection
		  con=getPooledConnection();
		ps=con.prepareStatement(GET_STUD_DETAILS);
		rs=ps.executeQuery();
		
		//copy ResultSet obj records  to ListBO 
		listBO=new ArrayList();
        
		while(rs.next()) {
			//copy each record to one BO class object
			bo=new StudentBO();
			bo.setSno(rs.getInt(1));
			bo.setName(rs.getString(2));
			bo.setAge(rs.getInt(3));
			bo.setAddrs(rs.getString(4));
			bo.setEmail(rs.getString(5));
			bo.setPhno(rs.getLong(6));
			//add Bo class objs to ListBO
			listBO.add(bo);
			
		}//while
		}catch (Exception e) {
			log.error(e);

		}
		finally {
			//close jdbc obj
			try {
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			
			try {
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
		}	return listBO;
		
		
	}//getStudentDetails()
	
	
	public List<FacultyBO> getFacultyDetails(){
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<FacultyBO> listBO=null;
		FacultyBO bo=null;
		try {
		//get pooled connection
		    con=getPooledConnection();
		
			ps=con.prepareStatement(GET_FAC_DETAILS);
			rs=ps.executeQuery();
			
			//copy ResultSet obj records  to ListBO 
			listBO=new ArrayList();
			
			while(rs.next()) {
				bo=new FacultyBO();
				bo.setSno(rs.getInt(1));
				bo.setName(rs.getString(2));
				bo.setEmail(rs.getString(3));
				bo.setPhno(rs.getLong(4));
				//add Bo class objs to ListBO
				listBO.add(bo);
			}
		} catch (SQLException se) {
			log.error(se);
		}
		
		finally {
			//close jdbc obj
			try {
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			
			try {
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
		}	
		
		return listBO;
		

		
		
	}//getFacultyDetails()
	
	//Rejection Method
	
	 public int RejectApplicantDetails(int id){
		Connection con=null;
		PreparedStatement ps=null;
		int status=0;
		 try {
		 //Get pooled connection
			 con=getPooledConnection();
        ps=con.prepareStatement(REJECT_APP);
        ps.setInt(1,id);
        status=ps.executeUpdate();
		
	 }catch (Exception e) {
		 log.error(e);

		}
		finally {
			//close jdbc obj
			
			try {
				if(ps!=null)
					ps.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
		}
		
		
        return status;
		
	}
	 
	 //Approve Method
	 public int ApproveApplicantDetails(int id){
			Connection con=null;
			PreparedStatement ps=null;
			int status=0;
			 try {
			//get connection
		    con=getPooledConnection();
	        ps=con.prepareStatement(APPROVE_APP);
	        ps.setInt(1,id);
	        status=ps.executeUpdate();
			}catch (Exception e) {
				log.error(e);

			}
			finally {
				//close jdbc obj
				
				try {
					if(ps!=null)
						ps.close();
				}
				catch(SQLException se) {
					log.error(se);

				}
				try {
					if(con!=null)
						con.close();
				}
				catch(SQLException se) {
					log.error(se);

				}
			}
			
	        
	        return status;
			
		}

}//class
