package com.nt.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.nt.bo.ApplicantBO;
import com.nt.controller.ApplicantControllerServlet;

public class ApplicantDAOImpl implements  ApplicantDAO {
	static Logger log = Logger.getLogger(ApplicantControllerServlet.class);
     private static final String APP_DET_INSERT="INSERT INTO APPLICANT VALUES(?,?,?,?,?,?,?,?,?)";
     private static final String GET_ID="select APP_NO_seq.NEXTVAL from dual";
     
     private static Connection getPooledConnection(){
	   	 Connection con=null;
	   	 InitialContext ic=null;
	   	 DataSource ds=null;
	   	 try {
	   	 //create initalContext obj
	   	 ic=new InitialContext();
	   	 ds=(DataSource) ic.lookup("java:/comp/env/mypool");
	   	 con=ds.getConnection();
	   	 }
	   	 catch(Exception e) {
	   		 log.error(e);
	   	 }
			return con;
	   	 
	    }
     
    
    
	@Override
	public int insert(ApplicantBO bo){
		Connection con=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		ResultSet rs=null;
		
		
		int count=0;
		 int app_Id=0;
		String default_status="InProcess";
		
		 try {
		//get connection
		 con=getPooledConnection();
			
		ps1=con.prepareStatement(GET_ID);
			 
		   rs= ps1.executeQuery();
		   if(rs.next())
		      app_Id=rs.getInt(1);
		  
			
		//create Prepare Statement
		ps2=con.prepareStatement(APP_DET_INSERT);
		//set values to query params
		ps2.setInt(1,app_Id);
		ps2.setString(2,bo.getName());
		ps2.setDate(3,new Date(bo.getDate().getTime()));
		ps2.setLong(4,bo.getPhno());
		ps2.setString(5,bo.getGender());
		ps2.setString(6,bo.getCourse());
		ps2.setString(7,bo.getEmailID());
		ps2.setString(8,bo.getAddr());
		ps2.setString(9,default_status);
		
		
		//execute the Query
		count=ps2.executeUpdate();
	    
	    
			
		
		}catch (Exception e) {
			log.error(e);

		}
		finally {
			try {
				if(rs!=null)
					rs.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(ps2!=null)
					ps2.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(ps1!=null)
					ps1.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
			try {
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				log.error(se);

			}
		}
		return app_Id;
	
		}//insert()
		
	
	}//class
