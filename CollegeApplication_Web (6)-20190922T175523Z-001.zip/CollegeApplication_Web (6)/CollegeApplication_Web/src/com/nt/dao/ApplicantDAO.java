package com.nt.dao;

import com.nt.bo.ApplicantBO;

public interface ApplicantDAO {
    public int insert(ApplicantBO bo);
    
}
