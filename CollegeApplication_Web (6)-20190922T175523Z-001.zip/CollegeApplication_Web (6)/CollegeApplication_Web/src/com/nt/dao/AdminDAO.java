package com.nt.dao;

import java.util.List;

import com.nt.bo.ApplicantBO;
import com.nt.bo.FacultyBO;
import com.nt.bo.StudentBO;

public interface AdminDAO {
   
    public List<ApplicantBO> getApplicantDetails();

    public List<StudentBO> getStudentDetails();
    
    public List<FacultyBO> getFacultyDetails();
   
}
