package com.nt.bo;

public class LoginBO {
     private int loginId;
     private String name;
     private String typeOfCandidate;
     private String userID;
     private String pwd;
     
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTypeOfCandidate() {
		return typeOfCandidate;
	}
	public void setTypeOfCandidate(String typeOfCandidate) {
		this.typeOfCandidate = typeOfCandidate;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}//class
