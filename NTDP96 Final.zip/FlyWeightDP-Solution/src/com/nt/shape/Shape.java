package com.nt.shape;

public interface Shape {
    public  void draw(int arg0,String fillColor,String lineStyle );
    
}
