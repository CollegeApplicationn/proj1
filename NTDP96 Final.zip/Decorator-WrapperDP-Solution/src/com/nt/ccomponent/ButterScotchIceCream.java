package com.nt.ccomponent;

import com.nt.component.IceCream;

public class ButterScotchIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("preparing butterScotch Icecream");

	}

}
