package com.nt.ccomponent;

import com.nt.component.IceCream;

public class StrawberryIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("preparing Strawberry Icecream");

	}

}
