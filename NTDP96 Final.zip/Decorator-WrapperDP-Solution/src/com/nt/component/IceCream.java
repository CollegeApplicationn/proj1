package com.nt.component;

public interface IceCream {
	public  void prepare();

}
