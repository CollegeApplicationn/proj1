package com.nt.factory;

public abstract class Car {
     public abstract void assemble();
     public  abstract void roadTest();
     public  abstract void  transportation();
}
