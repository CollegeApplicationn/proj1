package com.nt.product;

public class MarbleInterior implements Interior {
    @Override
    public String toString() {
         return "Marble Interior";
    }
}
