package com.nt.product;

public class IceBasement implements  Basement {

	@Override
	public String toString() {
	  return "ICE Basemennt";
	}

}
