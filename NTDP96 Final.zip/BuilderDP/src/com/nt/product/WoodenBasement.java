package com.nt.product;

public class WoodenBasement implements  Basement {

	@Override
	public String toString() {
	  return "Wooden Basemennt";
	}

}
