package com.nt.product;

public class WoodenRoof implements Roof {
	
	@Override
	public String toString() {
	   return "Concrete roof";
	}

}
