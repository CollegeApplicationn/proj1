package com.nt.product;

public class WoodenInterior implements Interior {
    @Override
    public String toString() {
         return "Wooden Interior";
    }
}
