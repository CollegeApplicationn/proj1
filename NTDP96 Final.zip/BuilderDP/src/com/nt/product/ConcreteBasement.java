package com.nt.product;

public class ConcreteBasement implements  Basement {

	@Override
	public String toString() {
	  return "Concrete Basemennt";
	}

}
