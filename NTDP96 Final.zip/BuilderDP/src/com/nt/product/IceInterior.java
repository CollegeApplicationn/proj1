package com.nt.product;

public class IceInterior implements Interior {
    @Override
    public String toString() {
         return "Ice Interior";
    }
}
