package com.nt.product;

public class IceStructure implements Structure {
	
	@Override
	public String toString() {
	   return "ICE structure";
	}

}
