package com.nt.product;

public class ConcreteStructure implements Structure {
	
	@Override
	public String toString() {
	   return "Concreate structure";
	}

}
