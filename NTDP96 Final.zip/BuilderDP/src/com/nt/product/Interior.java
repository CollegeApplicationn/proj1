package com.nt.product;

public interface Interior {

}
