package com.nt.product;

public class GlassInterior implements Interior {
    @Override
    public String toString() {
         return "Glass Interior";
    }
}
