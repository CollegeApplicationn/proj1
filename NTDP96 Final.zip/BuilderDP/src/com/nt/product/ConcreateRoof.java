package com.nt.product;

public class ConcreateRoof implements Roof {
	
	@Override
	public String toString() {
	   return "Concrete roof";
	}

}
