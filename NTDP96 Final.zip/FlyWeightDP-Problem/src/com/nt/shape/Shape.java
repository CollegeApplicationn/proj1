package com.nt.shape;

public interface Shape {
    public  void draw();
    public  void setArg(int arg);
    public void  setFillColor(String fillColor);
    public void  setLineStyle(String lineStyle);
}
