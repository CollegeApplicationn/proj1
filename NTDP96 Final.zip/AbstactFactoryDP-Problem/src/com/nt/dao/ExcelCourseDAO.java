package com.nt.dao;

public class ExcelCourseDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("inserting into Course Details into Excel");
	}

}
