package com.nt.dao;

public interface DAO {
	public void insert();

}
