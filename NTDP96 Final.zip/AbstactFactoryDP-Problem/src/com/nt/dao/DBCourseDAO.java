package com.nt.dao;

public class DBCourseDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("inserting into Course Details into DB");
	}

}
