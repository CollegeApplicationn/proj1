package com.nt.dao;

public class ExcelStudentDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("inserting into Student Details into Excel");
	}

}
