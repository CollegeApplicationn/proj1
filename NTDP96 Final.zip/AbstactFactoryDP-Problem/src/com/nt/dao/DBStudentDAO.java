package com.nt.dao;

public class DBStudentDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("inserting into Student Details into DB");
	}

}
