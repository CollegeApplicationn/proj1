package com.nt.bean;

public interface BankService {
	
	public String transferMoney(int srcAcc,int destAcc,int amount); 

}
