package com.nt.icecream;

public class VanilaIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("preparing vanila Icecream");

	}

}
