package com.nt.icecream;

public interface IceCream {
	public  void prepare();

}
