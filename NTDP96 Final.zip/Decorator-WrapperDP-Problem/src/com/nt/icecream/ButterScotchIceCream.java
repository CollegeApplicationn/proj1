package com.nt.icecream;

public class ButterScotchIceCream implements IceCream {

	@Override
	public void prepare() {
		System.out.println("preparing butterScotch Icecream");

	}

}
