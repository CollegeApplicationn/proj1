package com.nt.external;

import com.nt.dto.CardDetails;

public interface PayPalComp {
	public String  doPayment(CardDetails  details);

}
