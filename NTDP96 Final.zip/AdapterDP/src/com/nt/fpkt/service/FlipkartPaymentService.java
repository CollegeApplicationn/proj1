package com.nt.fpkt.service;

import com.nt.vo.PaymentDetailsVO;

public interface FlipkartPaymentService {
	
	public  String   processPayment(PaymentDetailsVO vo);

}
