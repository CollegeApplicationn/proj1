package com.nt.errors;

public class TooLargeValueException extends Exception {
	
	public TooLargeValueException(String msg) {
		super(msg);
	}

}
