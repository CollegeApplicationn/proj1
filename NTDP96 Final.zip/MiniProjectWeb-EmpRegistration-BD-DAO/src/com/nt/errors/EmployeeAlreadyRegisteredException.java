package com.nt.errors;

public class EmployeeAlreadyRegisteredException extends Exception {
	
	public EmployeeAlreadyRegisteredException(String msg) {
		super(msg);
	}

}
