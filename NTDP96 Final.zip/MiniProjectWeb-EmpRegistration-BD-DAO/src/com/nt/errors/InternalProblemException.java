package com.nt.errors;

public class InternalProblemException extends Exception {
	
	public InternalProblemException(String msg) {
		super(msg);
	}

}
