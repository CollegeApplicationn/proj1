package com.nt.bo;

public class HREmployeeBO extends BaseBO {
	private String empDesg;

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}


}
