package com.nt.bike;

public abstract class BajajBike {
	private int engineCC;
	public  abstract void  paint();
	public  abstract void assemble();
	public  abstract void oiling();
	public  abstract  void roadTest();
}
