package com.nt.external;

import com.nt.dto.StockIdDetailsDTO;

public interface StockIdDetailsFinderComp {
	
	public   StockIdDetailsDTO   getStockIdByNickName(String nickname);

}
