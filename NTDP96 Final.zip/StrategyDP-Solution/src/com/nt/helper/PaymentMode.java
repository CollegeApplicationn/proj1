package com.nt.helper;

public interface PaymentMode {
	public   String  doPayment(float amount,int orderId);

}
