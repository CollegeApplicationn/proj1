package com.nt.errors;

public class InternalRegistryProblem extends Exception {
	
	public InternalRegistryProblem(String msg) {
		super(msg);
	}

}
