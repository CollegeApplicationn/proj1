package com.nt.errors;

public class InternalDBProblem extends Exception {
	
	public InternalDBProblem(String msg) {
		super(msg);
	}

}
