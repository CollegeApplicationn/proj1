package com.nt.command;

public interface BankService {
    public   String  transferMoney(int srcAcno,int destAcno,float amt);
}
