package com.nt.dao;

public interface DepositeDAO {
	public int deposite(int acno,float amot);

}
