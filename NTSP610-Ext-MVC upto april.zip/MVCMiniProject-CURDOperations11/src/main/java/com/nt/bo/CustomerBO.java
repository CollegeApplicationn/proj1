package com.nt.bo;

import lombok.Data;

@Data
public class CustomerBO {
	private int cno;
	private String cname;
	private String cadd;
	private  long mobileNo;
	private  float billAmt;

}
