package com.nt.service;

import com.nt.dto.CustomerDTO;

public interface CustomerService {
   public String  register(CustomerDTO dto);
}
