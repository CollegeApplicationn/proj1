package com.nt.bo;

import lombok.Data;

@Data
public class EmployeeBO {
	private int empNo;
	private String ename;
	private String job;
	private float sal;
	
	
	

}
