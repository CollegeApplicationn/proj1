package com.nt.dao;

import java.util.List;

import com.nt.bo.ProductBO;

public interface ProductDAO {
	public  List<ProductBO>  getAllProducts();

}
