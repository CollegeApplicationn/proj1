package com.nt.service;

import java.util.List;

import com.nt.dto.ProductDTO;

public interface ProductMgmtService {
	public  List<ProductDTO>  fetchAllProducts();

}
