package com.atish.productService;

import java.util.List;

import com.atish.productEntity.ProductEntity;
import com.atish.productModel.ProductModel;

public interface ProductService {
	
	public List<ProductEntity> listAllProducts();
	public void saveProduct(ProductEntity entity);
	public ProductEntity findById(Integer id);
	public void deletById(Integer id);
	

}
