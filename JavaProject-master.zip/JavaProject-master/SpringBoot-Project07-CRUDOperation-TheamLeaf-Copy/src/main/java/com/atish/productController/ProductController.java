package com.atish.productController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.atish.productEntity.ProductEntity;
import com.atish.productService.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService prodService;
	
	@RequestMapping("/view")
	public String viewProducts(Model model) {
		List<ProductEntity> listProducts=prodService.listAllProducts();
		model.addAttribute("listProducts", listProducts);
		return "index1";
	}
	@GetMapping("/new")
	public String showProducts(Model model) {
		ProductEntity entity=new ProductEntity();
		model.addAttribute("product", entity);
		return "newProduct";
	}
	@PostMapping("/save")
	public String saveProduct(@ModelAttribute("product") ProductEntity entity) {
		prodService.saveProduct(entity);
		return "redirect:/view";	
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView editById(@PathVariable (name = "id")Integer id) {
		ModelAndView mav=new ModelAndView("editProduct");
		ProductEntity entity=prodService.findById(id);
		mav.addObject("product",entity);
		return mav;
	}
	@RequestMapping("/delete/{id}")
	public String deleteById(@PathVariable (name = "id")Integer id) {
		prodService.deletById(id);
		return "redirect:/view";
	}

}
