package com.atish.productServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atish.productEntity.ProductEntity;
import com.atish.productModel.ProductModel;
import com.atish.productRepository.ProductRepository;
import com.atish.productService.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository prodRepo;

	@Override
	public List<ProductEntity> listAllProducts() {
		return prodRepo.findAll();
	}

	@Override
	public void saveProduct(ProductEntity entity) {
		prodRepo.save(entity);
		
	}

	@Override
	public ProductEntity findById(Integer id) {
		return prodRepo.findById(id).get();
	}

	@Override
	public void deletById(Integer id) {
		 prodRepo.deleteById(id);
		
	}

}
