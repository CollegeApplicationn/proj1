package com.atish.productModel;

import java.io.Serializable;

import lombok.Data;

@Data
public class ProductModel implements Serializable{
	
	private Integer productId;
	private String productName;
	private String productCompany;
	private String productCountry;
	private Double companyPrice;
	private Double marketPrice;
	
	

}
