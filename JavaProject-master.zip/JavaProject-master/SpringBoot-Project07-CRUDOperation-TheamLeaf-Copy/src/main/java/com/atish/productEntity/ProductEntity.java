package com.atish.productEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "PROD_TAB")
@Data
public class ProductEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer productId;
	private String productName;
	private String productCompany;
	private String productCountry;
	private Double companyPrice;
	private Double marketPrice;
	
	

}
