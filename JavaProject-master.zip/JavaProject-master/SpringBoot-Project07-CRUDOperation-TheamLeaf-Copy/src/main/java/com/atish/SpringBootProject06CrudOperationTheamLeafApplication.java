package com.atish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProject06CrudOperationTheamLeafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProject06CrudOperationTheamLeafApplication.class, args);
	}

}
