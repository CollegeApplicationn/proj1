package atish.contact.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootContactApplicationTests {

	@Test
	void contextLoads() {
	}

}
