package atish.contact.com.model;

/**
 * This is a Contact Model Class Which is act as a Pojo Class or Domain Class
 * @author ATISH
 *
 */
public class ContactModel {
	
	private Integer contactId;
	private String contactName;
	private long contactNum;
	private String contactArea;

}