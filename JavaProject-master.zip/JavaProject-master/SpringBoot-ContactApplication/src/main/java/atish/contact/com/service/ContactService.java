package atish.contact.com.service;

import atish.contact.com.entity.ContactEntity;

/**
 * This is a ContactService Interface class Which is is Having only abstractMethods
 * @author ATISH
 *
 */
public interface ContactService {
	
	//public boolean  saveContactDetails(ContactEntity entity);
	public String  saveContactDetails(ContactEntity entity);


}
