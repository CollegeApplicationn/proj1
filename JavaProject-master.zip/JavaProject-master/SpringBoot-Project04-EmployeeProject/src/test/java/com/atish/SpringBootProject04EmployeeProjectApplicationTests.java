package com.atish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProject04EmployeeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
