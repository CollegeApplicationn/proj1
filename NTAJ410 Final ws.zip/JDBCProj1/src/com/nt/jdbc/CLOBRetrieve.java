package com.nt.jdbc;

public class CLOBRetrieve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
