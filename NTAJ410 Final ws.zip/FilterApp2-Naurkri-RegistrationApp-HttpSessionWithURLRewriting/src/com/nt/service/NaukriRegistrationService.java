package com.nt.service;

import com.nt.dto.JobSeekerDTO;

public interface NaukriRegistrationService {
     public   String   register(JobSeekerDTO dto)throws Exception;
}
