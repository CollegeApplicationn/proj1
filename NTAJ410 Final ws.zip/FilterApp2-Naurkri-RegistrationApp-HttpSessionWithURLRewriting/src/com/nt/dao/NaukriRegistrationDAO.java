package com.nt.dao;

import com.nt.bo.JobSeekerBO;

public interface NaukriRegistrationDAO {
	
	public  int   insert(JobSeekerBO bo)throws  Exception;

}
